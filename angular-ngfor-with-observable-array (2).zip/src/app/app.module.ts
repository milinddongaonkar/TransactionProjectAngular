import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { MyService } from './app.service';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionlistComponent } from './transactionlist/transactionlist.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent, TransactionComponent, TransactionlistComponent ],
  bootstrap:    [ AppComponent ],
  providers: [MyService]
})
export class AppModule { }
