import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MyService {

 
  mydata: MyDataType[] = [
    
  ];

  constructor() { }

  getData():Observable<MyDataType[]>
  {
    let data = new Observable<MyDataType[]>(observer => {
          setTimeout(() => {
              observer.next(this.mydata);
          }, 1);
    });
    return data;
  }
  adddata(data){
    this.mydata.push(JSON.parse(data));
  }
}

export class MyDataType
{
  public account1: string;
  public account2: string;
  public amount:string;
  public date:Date;
  
}