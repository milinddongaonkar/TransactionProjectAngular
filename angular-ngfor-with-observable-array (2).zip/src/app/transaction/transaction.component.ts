import { Component, OnInit } from '@angular/core';
import { MyService, MyDataType } from '../app.service';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

   myObservableArray: Observable<MyDataType[]>;

  constructor(private myService: MyService) {
    this.getData();
  }

  getData() {
    if (!this.myObservableArray) {
      this.myObservableArray = this.myService.getData();
    }
  }
  ngOnInit(){}

}