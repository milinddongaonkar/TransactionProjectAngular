import { Component, OnInit } from '@angular/core';
import { MyService, MyDataType } from '../app.service';
import { Observable } from 'rxjs/Observable';
import {NgForm} from '@angular/forms';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-transactionlist',
  template: `

  <form #f="ngForm" (ngSubmit)="onSubmit(f)" novalidate>
     <table>
     <tr> 
        <td>From Account No.</td>
        <td><input name="account1" ngModel required #account1="ngModel"></td>
      </tr>
      <tr>
        <td>BeneficiaryAccountNo.</td>
        <td><input name="account2" ngModel></td>
      </tr>
      <tr>
        <td>Amount</td>
        <td><input name="amount" ngModel></td>
      </tr>
      <tr>
        <td><label>Date</label></td>
        <td><input type="date" name="date"></td>
        </tr>

</table>
 <button  type="submit" >Submit Form</button>
  </form>
  `,
  styleUrls: ['./transactionlist.component.css']
})
export class TransactionlistComponent implements OnInit {

  constructor(private m:MyService) { }

  ngOnInit() {

  }
  onSubmit(f:NgForm){
     let data = JSON.stringify(f.value);
     
  this.m.adddata(data);
  }
}